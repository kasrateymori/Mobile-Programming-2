import 'dart:io';

void main() {
  stdout.write('نام دانش آموز را وارد کنید: ');
  String name = stdin.readLineSync()!;

  stdout.write('سن دانش آموز را وارد کنید: ');
  int age = int.parse(stdin.readLineSync()!);

  stdout.write('معدل دانش آموز را وارد کنید: ');
  double average = double.parse(stdin.readLineSync()!);

  print('نام: $name');
  print('سن: $age');
  print('معدل: $average');

  if (average >= 10) {
    print('دانش آموز قبول شده است');
  } else {
    print('دانش آموز مردود شده است');
  }
}
