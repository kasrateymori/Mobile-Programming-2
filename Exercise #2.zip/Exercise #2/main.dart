import 'dart:io';

void main() {
  List<double> grades = [];

  stdout.write('تعداد نمرات را وارد کنید: ');
  int count = int.parse(stdin.readLineSync()!);

  for (int i = 0; i < count; i++) {
    stdout.write('نمره نفر ${i + 1} را وارد کنید: ');
    double grade = double.parse(stdin.readLineSync()!);

    grades.add(grade);
  }

  double sum = 0;
  int passed = 0;

  for (int i = 0; i < grades.length; i++) {
    sum += grades[i];

    if (grades[i] > 10) {
      passed++;
    }
  }

  double average = sum / grades.length;

  print('میانگین نمرات: $average');
  print('تعداد افراد با نمره بیشتر از 10: $passed');
}