import 'dart:io';

void main() {
  String password = '123456';

  stdout.write('رمز عبور را وارد کنید: ');
  String userPassword = stdin.readLineSync()!;

  while (userPassword != password) {
    print('رمز نادرست است');

    stdout.write('دوباره رمز را وارد کنید: ');
    userPassword = stdin.readLineSync()!;
  }

  print('رمز درست است');
}
